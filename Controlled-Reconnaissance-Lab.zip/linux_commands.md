# Linux Fundamentals – Practical Notes

## 1. Aim
Understand files, directories, permissions, users, groups, processes, and basic system information in Linux.

## 2. Commands to practise

| Command | Purpose |
|---|---|
| `pwd` | Print current working directory |
| `ls -la` | List files, including hidden files |
| `mkdir lab` | Create a directory named `lab` |
| `cd lab` | Change into the directory |
| `touch notes.txt` | Create an empty file |
| `cat notes.txt` | Display file contents |
| `cp notes.txt copy.txt` | Copy a file |
| `mv copy.txt renamed.txt` | Rename or move a file |
| `whoami` | Show current username |
| `id` | Show user and group IDs |
| `groups` | Show groups for current user |
| `ps` | Display process information |
| `top` | Monitor running processes |
| `uname -a` | Display kernel/system information |
| `ip addr` | Display network interfaces and addresses |

## 3. Safe practice exercise

```bash
mkdir -p ~/recon-lab/linux-practice
cd ~/recon-lab/linux-practice
touch notes.txt
echo "Linux practice completed" > notes.txt
cat notes.txt
ls -la
pwd
whoami
id
ps
```

## 4. Permissions
Linux permissions are read (`r`), write (`w`), and execute (`x`). They apply to the owner, group, and others.

Example: `chmod 600 notes.txt` gives the owner read/write access and removes access for group and others. Use this only on your own practice file.

Check permissions with:

```bash
ls -l notes.txt
```

## 5. Record your result
- Linux distribution/version: [Fill in]
- Commands practised: [Fill in]
- Screenshot filename: [Add your screenshot]
- What I learned: [Write 2–3 sentences]
