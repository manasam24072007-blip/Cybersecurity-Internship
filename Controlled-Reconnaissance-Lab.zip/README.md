# Controlled Reconnaissance Lab

**Internship:** Codomax Digital – Module 02  
**Module:** Linux, Security Tools & Reconnaissance  
**Author:** Manasa

## Objective
This beginner-friendly project documents Linux fundamentals, passive and active reconnaissance, DNS basics, and introductory use of Nmap, Wireshark, Burp Suite, and OWASP ZAP in an authorized lab.

## Scope and safety
- Test only systems, networks, and applications you own or have explicit permission to assess.
- Use localhost or a deliberately vulnerable local application such as OWASP Juice Shop.
- Do not scan public IP addresses or websites without written authorization.
- Do not include passwords, tokens, personal data, or other secrets in this repository.

## Repository contents
- `linux_commands.md` – Linux fundamentals and example commands
- `reconnaissance.md` – Passive/active reconnaissance and DNS
- `nmap.md` – Safe local Nmap practice
- `wireshark.md` – Packet capture and display-filter practice
- `burpsuite.md` – Inspecting requests in a local test application
- `owasp_zap.md` – Local web application testing
- `security_report.md` – Report template for recording actual observations
- `Screenshots/` – Add your own screenshots of completed practical work

## Important
Commands and observations in these documents are practice guidance, not proof that a test has been performed. Replace report placeholders with your actual results and screenshots before submitting.
