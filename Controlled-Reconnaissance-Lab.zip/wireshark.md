# Wireshark – Packet Analysis Practical

## 1. Introduction
Wireshark is a network protocol analyzer. It captures and displays packets so an analyst can understand network communication and troubleshoot issues.

## 2. Basic workflow
1. Open Wireshark.
2. Select an interface you are permitted to monitor (for example, your own test interface).
3. Start capture.
4. Generate ordinary test traffic, such as visiting a local test page.
5. Apply a display filter.
6. Stop the capture.
7. Save only a sanitized capture if it is appropriate to share.

## 3. Useful display filters

| Filter | Purpose |
|---|---|
| `dns` | Show DNS packets |
| `tcp` | Show TCP packets |
| `udp` | Show UDP packets |
| `http` | Show HTTP packets, if present |
| `ip.addr == 127.0.0.1` | Filter packets involving loopback IPv4 |

Note: Loopback traffic visibility depends on the operating system and capture interface.

## 4. What to observe
- Source and destination addresses
- Protocol
- Packet length
- DNS query/response information
- TCP connection setup, when visible

## 5. Record your result
- Interface used: [Fill in]
- Filter used: [Fill in]
- Protocols observed: [Fill in]
- What I learned: [Fill in]
- Screenshot filename: [Add your screenshot]

## 6. Privacy and safety
Captures may contain sensitive information. Capture only traffic you are authorized to inspect. Remove credentials, cookies, personal data, and unrelated traffic before sharing.
