# OWASP ZAP – Web Application Security Testing

## 1. Introduction
OWASP ZAP (Zed Attack Proxy) is a free, open-source tool for finding potential security issues in web applications.

## 2. Safe lab setup
Use a local training application, such as OWASP Juice Shop running on your own computer. Only scan applications that you own or have explicit permission to test.

## 3. Basic manual workflow
1. Install and open OWASP ZAP.
2. Start a session.
3. Use the Manual Explore option or configure the browser to use ZAP.
4. Browse the local test application.
5. Review the **Sites**, **History**, and **Alerts** panels.
6. Read each alert and its evidence carefully.
7. Export a report only after reviewing it for sensitive information.

## 4. Understanding alerts
ZAP alerts are findings that need validation. An alert is not automatically proof of an exploitable vulnerability. Review the risk, confidence, evidence, and recommended solution.

## 5. Record your result
- Local target: [Fill in]
- ZAP version: [Fill in]
- Number of alerts observed: [Fill in actual count]
- One alert reviewed: [Fill in]
- Was it manually validated? [Yes/No and explain]
- Screenshot filename: [Add your screenshot]

## 6. Safety
Do not run active scans against public or third-party websites without explicit written authorization and an agreed testing scope.
