# Controlled Reconnaissance Lab – Security Report

**Student:** Manasa  
**Internship:** Codomax Digital – Module 02  
**Module:** Linux, Security Tools & Reconnaissance  
**Assessment date:** [Enter date]

## 1. Objective
To practise Linux fundamentals and learn basic reconnaissance and security analysis using Nmap, Wireshark, Burp Suite, and OWASP ZAP in a controlled, authorized lab.

## 2. Scope and authorization
**Target/application:** [Enter your local lab target]  
**Reason it is in scope:** [Explain that you own it or have permission]  
**Out-of-scope systems:** All unrelated public and third-party systems.

## 3. Tools used
- Linux: [Distribution and version]
- Nmap: [Version]
- Wireshark: [Version]
- Burp Suite: [Edition/version]
- OWASP ZAP: [Version]

## 4. Methodology
1. Reviewed Linux files, directories, permissions, users, groups, and processes.
2. Learned passive and active reconnaissance concepts.
3. Queried DNS information for a permitted example domain.
4. Performed an Nmap check against localhost or an authorized lab host.
5. Captured and inspected permitted lab traffic in Wireshark.
6. Inspected requests to a local test application using Burp Suite.
7. Reviewed OWASP ZAP alerts for the local test application.

## 5. Results
Complete this table only with results you personally observed.

| Activity | Actual observation | Evidence |
|---|---|---|
| Linux commands | [Fill in] | [Screenshot name] |
| DNS lookup | [Fill in] | [Screenshot name] |
| Nmap | [Fill in] | [Screenshot name] |
| Wireshark | [Fill in] | [Screenshot name] |
| Burp Suite | [Fill in] | [Screenshot name] |
| OWASP ZAP | [Fill in] | [Screenshot name] |

## 6. Findings and recommendations
**Finding 1:** [Describe an observed issue or state that no issue was confirmed.]  
**Evidence:** [Reference screenshot or sanitized output.]  
**Recommendation:** [Practical remediation or follow-up.]

Do not claim a vulnerability unless you have validated it. Distinguish tool alerts from confirmed findings.

## 7. Limitations
- Testing was limited to the stated lab scope.
- Tool output may contain false positives or incomplete information.
- No claim is made about systems that were not tested.

## 8. Conclusion
This lab provided introductory practical experience with Linux, reconnaissance, DNS, network packet analysis, and web security testing tools. The observations and screenshots in this report should reflect the tests actually completed.

## 9. Evidence checklist
- [ ] Linux terminal screenshot
- [ ] DNS lookup screenshot
- [ ] Nmap localhost/lab screenshot
- [ ] Wireshark screenshot with a display filter
- [ ] Burp Suite local request screenshot
- [ ] OWASP ZAP local lab screenshot
