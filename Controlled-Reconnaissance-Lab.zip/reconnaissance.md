# Reconnaissance – Notes and Practice

## 1. Definition
Reconnaissance is the information-gathering phase of a security assessment. It helps an authorized tester understand the scope and visible characteristics of a target before testing.

## 2. Passive reconnaissance
Passive reconnaissance uses publicly available information without directly probing the target system.

Examples:
- Reviewing an organization's public website.
- Checking public domain registration information where available.
- Looking up publicly published DNS records.
- Reviewing public documentation.

## 3. Active reconnaissance
Active reconnaissance directly interacts with an in-scope system. It can create logs or affect the target, so it requires explicit authorization.

Examples:
- Scanning a lab host for open ports.
- Checking services on a local test machine.
- Observing responses from a local test web application.

## 4. DNS basics
DNS (Domain Name System) translates domain names into IP addresses and provides other domain-related records.

| Record | Meaning |
|---|---|
| A | IPv4 address |
| AAAA | IPv6 address |
| MX | Mail exchanger |
| NS | Authoritative name server |
| CNAME | Canonical name/alias |
| TXT | Text data, often used for verification and email policies |

Example lookup for a public example domain:

```bash
nslookup example.com
```

If installed, `dig` can also be used:

```bash
dig example.com A
dig example.com MX
```

## 5. Practice and ethics
Only perform active checks against localhost, your own lab, or a target explicitly authorized by its owner. Do not treat public availability as permission.

## 6. Record your result
- Lab target and why it is in scope: [Fill in]
- DNS command used: [Fill in]
- Result summary: [Fill in]
- Screenshot filename: [Add your screenshot]
