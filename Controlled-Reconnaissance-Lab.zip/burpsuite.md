# Burp Suite – Web Request Inspection

## 1. Introduction
Burp Suite is a web application security testing platform. Its proxy can help an authorized tester inspect HTTP requests and responses between a browser and a test application.

## 2. Safe lab setup
Use a local application that you own or a deliberately vulnerable training application such as OWASP Juice Shop running locally. Do not test third-party websites without written permission.

## 3. Basic workflow
1. Open Burp Suite Community Edition.
2. Start a temporary project and use the default configuration.
3. Start Burp.
4. Open Burp's built-in browser.
5. Visit your local test application.
6. Open **Proxy → HTTP history**.
7. Select a request and inspect its request and response details.

## 4. Concepts
- **Proxy:** Relays browser traffic through Burp.
- **HTTP request:** A client message sent to a web server.
- **HTTP response:** The server's reply.
- **Headers:** Metadata associated with a request or response.
- **Status code:** A number describing the response outcome.

## 5. Record your result
- Local test application: [Fill in]
- Request method observed: [Fill in]
- Response status observed: [Fill in]
- Interesting header (do not include secrets): [Fill in]
- Screenshot filename: [Add your screenshot]

## 6. Safety
Keep testing within the local lab and avoid saving or sharing session cookies, authorization headers, passwords, or personal data.
