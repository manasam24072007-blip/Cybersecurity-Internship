# Nmap – Network Mapper Practical

## 1. Introduction
Nmap (Network Mapper) is a tool used to discover hosts and examine ports and services on systems that are within an authorized assessment scope.

## 2. Check installation

```bash
nmap --version
```

## 3. Safe localhost practice

```bash
nmap 127.0.0.1
```

This checks the local computer's loopback address.

Service/version detection on localhost:

```bash
nmap -sV 127.0.0.1
```

## 4. Understand common terms
- **Host:** A device on a network.
- **Port:** A numbered communication endpoint.
- **Open port:** A service is listening and accepting connections.
- **Service detection:** Attempts to identify the service and version.

## 5. Record your result
- Date/time: [Fill in]
- System tested: `127.0.0.1` (or your explicitly authorized lab host)
- Nmap version: [Fill in]
- Command used: [Fill in]
- Actual result: [Paste a short summary; do not invent results]
- Screenshot filename: [Add your screenshot]

## 6. Safety
Do not scan networks, websites, or IP addresses unless you own them or have explicit permission and a defined scope.
